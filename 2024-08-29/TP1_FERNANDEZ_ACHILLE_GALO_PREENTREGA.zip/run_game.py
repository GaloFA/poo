""" Import """
from player_interaction import PlayerInteraction

interact = PlayerInteraction()

interact.run_game()
